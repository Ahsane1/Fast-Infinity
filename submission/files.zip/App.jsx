import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login      from './pages/Login';
import CampusLayout from './components/CampusLayout';
import Hub        from './pages/Hub';
import Cafeteria  from './pages/Cafeteria';
import ESports    from './pages/ESports';
import Bookshop   from './pages/Bookshop';
import Snake      from './pages/games/Snake';

export default function App() {
    return (
        <BrowserRouter>
            <Routes>
                {/* Public */}
                <Route path="/login" element={<Login />} />

                {/* Protected — wrapped in sidebar/topbar layout */}
                <Route element={<CampusLayout />}>
                    <Route path="/"              element={<Hub />} />
                    <Route path="/cafeteria"     element={<Cafeteria />} />
                    <Route path="/esports"       element={<ESports />} />
                    <Route path="/esports/snake" element={<Snake />} />
                    <Route path="/bookshop"      element={<Bookshop />} />
                </Route>
            </Routes>
        </BrowserRouter>
    );
}
